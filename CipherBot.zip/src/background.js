const getElementsClassname = async () => {
  console.log("Get Elements Classname Triggered ✨");
  try {
    const response = await fetch("https://api.tradeonnova.io/api-v1/elements", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error("Failed to get elements classname: ", response);
    }

    let result = await response.json();

    result = processUnicodeEscapes(result);

    if (result) {
      console.log("Success to get elements classname ✅: ", result);
      chrome.storage.local.set(
        {
          elements_classname: result,
          is_buy_photon: true,
          is_buy_bullx: true,
          is_buy_legacybullx: true,
          is_buy_neobullx: true,
          is_buy_neobackupbullx: true,
          is_buy_gmgn: true,
          is_buy_axiom: true,
          is_buy_pumpfun: true,
          discord_state: {
            buy_history: [],
            windows: [],
          },
          telegram_state: {
            buy_history: [],
            windows: [],
          },
          show_flying_modal: false,
          show_flying_modal: true,
          flying_modal_position: {
            top: 50,
            left: 100,
          },
          custom_buy_value_list: [0.5, 1, 2, 5, 10],
          custom_sell_value_list: [10, 25, 50, 100],
          default_buy_amount: 0.01,
          active_preset_label: "S1",
          active_preset_values: {
            "buy-fee": 0.001,
            "buy-tip": 0.005,
            "buy-slippage": 50,
            "sell-fee": 0.001,
            "sell-tip": 0.005,
            "sell-slippage": 50,
          },
          first_preset_values: {
            "buy-fee": 0.001,
            "buy-tip": 0.005,
            "buy-slippage": 50,
            "sell-fee": 0.001,
            "sell-tip": 0.005,
            "sell-slippage": 50,
          },
          second_preset_values: {
            "buy-fee": 0.005,
            "buy-tip": 0.01,
            "buy-slippage": 60,
            "sell-fee": 0.005,
            "sell-tip": 0.01,
            "sell-slippage": 60,
          },
        },
        () => {},
      );
    }
  } catch (error) {
    console.error("Error get elements classname: ", error);
  }
};

const processUnicodeEscapes = (obj) => {
  if (typeof obj !== "object" || obj === null) return obj;
  return Object.fromEntries(
    Object.entries(obj).map(([key, value]) => {
      if (typeof value === "string") {
        return [
          key,
          value.replace(/\\u([0-9a-fA-F]{4})/g, (match, code) =>
            String.fromCharCode(parseInt(code, 16)),
          ),
        ];
      }
      if (typeof value === "object") {
        return [key, processUnicodeEscapes(value)];
      }
      return [key, value];
    }),
  );
};

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
    console.log("Cipher Extension Initialization 🚩");
    chrome.storage.local.clear(() => {
      chrome.storage.local.set({
        'is_nova_extension_on': true,
        'nova_auth_token': true
      }, () => {
        getElementsClassname();
      });
    });
  }
  if (details.reason === chrome.runtime.OnInstalledReason.UPDATE) {
    getElementsClassname();
  }
});

chrome.tabs.onActivated.addListener(async (activatedInfo) => {
  const windowId = await getWindowId();
  if (!activatedInfo.tabId) return;
  chrome.tabs
    .sendMessage(activatedInfo?.tabId, { context: "Trigger base.js", windowId })
    .then(() => {})
    .catch((err) => {});
  chrome.tabs.get(activatedInfo.tabId, (tab) => {
    const message = getMessage(tab?.url);
    if (message) {
      chrome.tabs
        .sendMessage(activatedInfo.tabId, { message, windowId })
        .then(() => {})
        .catch((err) => {});
    }
  });
});
chrome.runtime.onMessage.addListener((request) => {
  if (request.context === "Cipher Auth Token Found 🪙") {
    chrome.storage.local.set(
      {
        nova_auth_token: request.token,
      },
      () => {},
    );
  }
});

const getWindowId = async () => {
  return (await chrome.windows.getCurrent()).id;
};

const getMessage = (url) => {
  try {
    const parsedUrl = new URL(url);
    const pathname = parsedUrl.pathname;
    if (url.includes("twitter.com") || url.includes("x.com")) {
      return "twitter-content";
    } else if (url.startsWith("https://photon-sol.tinyastro.io/")) {
      if (pathname.startsWith("/en/lp/") || pathname.startsWith("/zn/lp/")) {
        return "photon-token";
      } else {
        chrome.storage.local.set(
          {
            is_buy_photon: true,
          },
          () => {
            console.log("Success to reset buy status on photon ✅");
          },
        );
      }
      if (
        pathname.startsWith("/en/memescope") ||
        pathname.startsWith("/zh/memescope")
      )
        return "photon-memescope";
    } else if (
      [
        "https://bullx.io/",
        "https://backup.bullx.io/",
        "https://backup2.bullx.io/",
      ].some((mappedUrl) => url.startsWith(mappedUrl))
    ) {
      if (pathname.startsWith("/terminal")) {
        return "bullx-token";
      } else {
        chrome.storage.local.set(
          {
            is_buy_bullx: true,
          },
          () => {
            console.log("Success to reset buy status on bullx ✅");
          },
        );
      }
      if (pathname.startsWith("/pump-vision")) return "bullx-pump-vision";
    } else if (url.startsWith("https://neo.bullx.io/")) {
      if (pathname.startsWith("/terminal")) {
        return "neo-bullx-token";
      } else {
        chrome.storage.local.set(
          {
            is_buy_neobullx: true,
          },
          () => {
            console.log("Success to reset buy status on neobullx ✅");
          },
        );
      }
      if (pathname.startsWith("/")) return "neo-bullx-pump-vision";
    } else if (url.startsWith("https://neo-backup.bullx.io/")) {
      if (pathname.startsWith("/terminal")) {
        return "neo-backup-bullx-token";
      } else {
        chrome.storage.local.set(
          {
            is_buy_neobackupbullx: true,
          },
          () => {
            console.log("Success to reset buy status on neobackupbullx ✅");
          },
        );
      }
      if (pathname.startsWith("/")) return "neo-backup-bullx-pump-vision";
    } else if (url.startsWith("https://legacy.bullx.io/")) {
      if (pathname.startsWith("/terminal")) {
        return "legacy-bullx-token";
      } else {
        chrome.storage.local.set(
          {
            is_buy_legacybullx: true,
          },
          () => {
            console.log("Success to reset buy status on legacybullx ✅");
          },
        );
      }
      if (pathname.startsWith("/")) return "legacy-bullx-pump-vision";
    } else if (url.startsWith("https://gmgn.ai/")) {
      if (pathname.startsWith("/sol/token")) {
        return "gmgn-token";
      } else {
        chrome.storage.local.set(
          {
            is_buy_gmgn: true,
          },
          () => {
            console.log("Success to reset buy status on gmgn ✅");
          },
        );
      }
      if (pathname.startsWith("/meme")) return "gmgn-memescope";
    } else if (url.startsWith("https://axiom.trade/")) {
      if (pathname.startsWith("/meme")) {
        return "axiom-token";
      } else {
        chrome.storage.local.set(
          {
            is_buy_axiom: true,
          },
          () => {
            console.log("Success to reset buy status on axiom ✅");
          },
        );
      }
      if (pathname.startsWith("/pulse")) return "axiom-memescope";
    } else if (url.startsWith("https://pump.fun/")) {
      if (pathname.startsWith("/coin")) {
        return "pumpfun-token";
      } else {
        chrome.storage.local.set(
          {
            is_buy_pumpfun: true,
          },
          () => {
            console.log("Success to reset buy status on pumpfun ✅");
          },
        );
      }
      if (pathname.startsWith("/board")) return "pumpfun-memescope";
    } else if (url.startsWith("https://discord.com/")) {
      if (pathname.startsWith("/channels/")) return "discord-chatroom";
    } else if (url.startsWith("https://web.telegram.org/")) {
      if (pathname.startsWith("/a/")) return "telegram-chatroom-a";
      if (pathname.startsWith("/k/")) return "telegram-chatroom-k";
    }
    return;
  } catch (error) {
    console.log("INVALID URL ❌", url, error);
    return;
  }
};
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  const windowId = await getWindowId();
  if (
    changeInfo.url &&
    changeInfo.url.includes("https://web.telegram.org/") &&
    changeInfo.status === "loading"
  ) {
    if (!windowId) return;
    const message = getMessage(changeInfo.url);
    if (message) {
      chrome.tabs
        .sendMessage(tabId, { message, windowId, changeInfo })
        .then(() => {})
        .catch((err) => {});
    }
  }
  if (!changeInfo.url || changeInfo.status !== "complete" || !windowId) return;
  const message = getMessage(changeInfo.url);
  if (message) {
    chrome.tabs
      .sendMessage(tabId, { message, windowId, changeInfo })
      .then(() => {})
      .catch((err) => {});
  }
});

const handleNavigation = async (details, variant) => {
  const windowId = await getWindowId();
  if (!details.url || !windowId) return;

  const message = getMessage(details.url);
  if (message) {
    const maxRetries = 5;
    let attempt = 0;

    const sendMessageWithRetry = () => {
      chrome.tabs
        .sendMessage(details.tabId, { message, windowId })
        .then(() => {})
        .catch((err) => {
          attempt++;
          if (attempt < maxRetries) {
            setTimeout(sendMessageWithRetry, Math.pow(2, attempt) * 100);
          } else {
          }
        });
    };

    sendMessageWithRetry();
  }
};
chrome.webNavigation.onCompleted.addListener((event) =>
  handleNavigation(event, "ON COMPLETED"),
);
chrome.webNavigation.onHistoryStateUpdated.addListener((event) =>
  handleNavigation(event, "ON HISTORY UPDATED"),
);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'fetchWaitList') {
    fetch(message.url)
      .then(response => response.json())
      .then(data => {
        sendResponse({ value: data.value });
      })
      .catch(error => {
        console.error('Error:', error);
        sendResponse({ value: '--' });
      });
    return true;
  }
}); 
